package robotEnums;

public enum Direction {
	UP, LEFT, DOWN, RIGHT
}
